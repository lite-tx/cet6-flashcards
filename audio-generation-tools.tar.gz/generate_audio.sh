#!/bin/bash

# 语音缓存生成脚本

echo "========================================="
echo " 开始生成单词语音缓存..."
echo "========================================="

# 检查 Python 虚拟环境
if [ ! -d "venv" ]; then
    echo "错误: 虚拟环境不存在！请先运行 'python3 -m venv venv' 创建虚拟环境"
    exit 1
fi

# 激活虚拟环境
echo "激活虚拟环境..."
source venv/bin/activate

# 安装依赖（如果需要）
echo "检查依赖..."
pip install -q aiohttp aiofiles

# 启动 RVC 服务器（如果还未运行）
echo "检查 RVC 服务器状态..."
if ! curl -s http://localhost:8765/health > /dev/null 2>&1; then
    echo "RVC 服务器未运行，正在启动..."
    ./start_rvc_server.sh &
    sleep 5
fi

# 运行音频生成脚本
echo "开始生成音频..."
python3 generate_audio_cache.py

echo "========================================="
echo " 音频缓存生成完成！"
echo "========================================="
