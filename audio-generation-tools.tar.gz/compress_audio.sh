#!/bin/bash

# 音频缓存压缩脚本

echo "========================================="
echo " CET6 离线语音包压缩工具"
echo "========================================="

# 检查 audio_cache 目录
if [ ! -d "audio_cache" ]; then
    echo "错误: audio_cache 目录不存在！"
    echo "请先运行 ./generate_audio.sh 生成音频文件"
    exit 1
fi

# 统计音频文件数量
AUDIO_COUNT=$(ls audio_cache/*.wav 2>/dev/null | wc -l)
echo "找到 $AUDIO_COUNT 个音频文件"

if [ "$AUDIO_COUNT" -eq 0 ]; then
    echo "错误: audio_cache 目录中没有音频文件！"
    exit 1
fi

# 检查 cache_index.json
if [ ! -f "audio_cache/cache_index.json" ]; then
    echo "警告: 未找到 cache_index.json，尝试生成..."
    source venv/bin/activate 2>/dev/null
    python3 -c "
import json
import os
import glob
import time

audio_files = {}
for audio_file in glob.glob('audio_cache/*.wav'):
    word_name = os.path.basename(audio_file).replace('.wav', '')
    audio_files[word_name] = {
        'file': audio_file,
        'size': os.path.getsize(audio_file),
        'created': os.path.getctime(audio_file)
    }

cache_info = {
    'total_count': len(audio_files),
    'generated_time': time.time(),
    'rvc_enabled': True,
    'words': audio_files
}

with open('audio_cache/cache_index.json', 'w', encoding='utf-8') as f:
    json.dump(cache_info, f, indent=2, ensure_ascii=False)

print(f'生成索引文件: {len(audio_files)} 个单词')
    "
fi

# 显示音频包信息
echo ""
echo "音频包信息:"
echo "  音频文件数: $AUDIO_COUNT"
echo "  目录大小: $(du -sh audio_cache/ | cut -f1)"

# 生成压缩包名称
DATE_SUFFIX=$(date +%Y%m%d)
OUTPUT_FILE="cet6-audio-cache-${DATE_SUFFIX}.tar.gz"

echo ""
echo "开始压缩..."
echo "输出文件: $OUTPUT_FILE"

# 压缩
tar -czf "$OUTPUT_FILE" audio_cache/

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================="
    echo " 压缩完成！"
    echo "========================================="
    echo "压缩包: $OUTPUT_FILE"
    echo "大小: $(du -h "$OUTPUT_FILE" | cut -f1)"
    echo ""
    echo "使用方法:"
    echo "  1. 解压: tar -xzf $OUTPUT_FILE"
    echo "  2. 启动应用: trunk serve --open"
    echo "  3. 点击 Live2D 即可听到单词发音"
    echo ""
    echo "分享给其他人:"
    echo "  他们只需要解压并运行 trunk serve 即可使用离线语音"
else
    echo "错误: 压缩失败！"
    exit 1
fi
