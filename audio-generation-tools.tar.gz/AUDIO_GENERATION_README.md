# 音频生成工具说明

本目录包含用于生成 RVC 语音缓存的工具文件。

## ⚠️ 重要说明

**日常使用不需要这些文件！**

本项目已经预生成了所有单词的离线语音（`audio_cache/`），可以直接使用：

```bash
trunk serve --open
```

点击 Live2D 看板娘即可听到单词发音，完全离线，无需任何配置。

## 📦 工具文件列表

本压缩包包含以下文件：

- `rvc_server.py` - RVC 语音合成服务器
- `generate_audio_cache.py` - 批量生成音频缓存的脚本
- `generate_audio.sh` - 一键启动音频生成的便捷脚本
- `compress_audio.sh` - 压缩音频包的脚本
- `quick_guide.sh` - 快速使用指南
- `start_rvc_server.sh` - 启动 RVC 服务器的脚本
- `requirements.txt` - Python 依赖（仅音频生成需要的部分）

## 🔧 何时需要这些工具？

只有在以下情况下才需要使用这些工具：

1. **重新生成音频**：想要使用不同的 RVC 模型重新生成所有单词的语音
2. **自定义语音**：替换 RVC 模型文件，生成自己喜欢的声音
3. **添加新单词**：词库更新后需要生成新单词的音频
4. **修复损坏**：某些音频文件损坏需要重新生成

## 🚀 使用步骤

### 1. 解压工具文件

```bash
tar -xzf audio-generation-tools.tar.gz
```

### 2. 安装 Python 依赖

```bash
# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 安装 PyTorch（重要！）
pip install torch==2.3.0+cu121 torchaudio==2.3.0+cu121 \
    --extra-index-url https://download.pytorch.org/whl/cu121
```

### 3. 准备 RVC 模型

将你的 RVC 模型文件放到 `11_RVC/` 目录：

```
11_RVC/
├── your_model.pth
└── your_index.index（可选）
```

修改 `rvc_server.py` 中的路径：

```python
RVC_MODEL_PATH = "11_RVC/your_model.pth"
RVC_INDEX_PATH = "11_RVC/your_index.index"
```

### 4. 生成音频

```bash
# 一键生成所有单词的音频（需要 2-3 小时）
./generate_audio.sh

# 或者查看详细进度
tail -f audio_generation.log
```

### 5. 压缩音频包

```bash
# 生成完成后压缩音频包
./compress_audio.sh
```

## 📋 依赖说明

音频生成需要以下 Python 包：

```
edge-tts>=6.1.0          # 微软 Edge TTS
rvc-python>=0.1.0        # RVC 语音转换
fastapi>=0.104.0         # Web 服务器
uvicorn>=0.24.0          # ASGI 服务器
aiohttp>=3.9.0           # 异步 HTTP 客户端
aiofiles>=23.2.1         # 异步文件操作
torch==2.3.0+cu121       # PyTorch（GPU 版本）
torchaudio==2.3.0+cu121  # 音频处理
```

**如果只使用离线音频，不需要安装这些依赖。**

## ⚙️ 配置选项

### RVC 服务器配置（`rvc_server.py`）

```python
# RVC 模型路径
RVC_MODEL_PATH = "11_RVC/your_model.pth"
RVC_INDEX_PATH = "11_RVC/your_index.index"

# 服务器端口
PORT = 8765

# GPU 设备
DEVICE = "cuda"  # 或 "cpu"
```

### 音频生成配置（`generate_audio_cache.py`）

```python
# 批量大小（并发请求数）
BATCH_SIZE = 10

# RVC 服务器地址
RVC_SERVER_URL = "http://localhost:8765"

# 输出目录
OUTPUT_DIR = "audio_cache"
```

## 🔍 故障排除

### PyTorch 版本错误

**症状**：`weights_only` 错误

**解决**：
```bash
pip install torch==2.3.0+cu121 torchaudio==2.3.0+cu121 \
    --extra-index-url https://download.pytorch.org/whl/cu121
```

### RVC 服务器启动失败

**症状**：端口被占用

**解决**：
```bash
# 查找占用端口的进程
lsof -i:8765

# 或修改端口
vim rvc_server.py  # 修改 PORT 变量
```

### 音频生成中断

**症状**：进程被打断

**解决**：
```bash
# 直接再次运行，会跳过已生成的文件
./generate_audio.sh
```

## 📚 更多信息

详细文档请参考主项目的 `README.md` 文件。

---

**提示**：日常使用本项目无需这些工具，已预生成的离线音频即可满足需求。
