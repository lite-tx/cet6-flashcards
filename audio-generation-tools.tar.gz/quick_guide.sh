#!/bin/bash

# CET6 离线语音包 - 快速使用指南

cat << 'EOF'

╔══════════════════════════════════════════════════════════╗
║     CET6 智能单词学习工具 - 离线语音包               ║
║     音频生成和压缩工具使用指南                           ║
╚══════════════════════════════════════════════════════════╝

📋 当前状态
-----------------------------------------------------------
EOF

# 检查音频生成状态
if [ -d "audio_cache" ]; then
    AUDIO_COUNT=$(ls audio_cache/*.wav 2>/dev/null | wc -l)
    TOTAL=5660
    PROGRESS=$(echo "scale=1; $AUDIO_COUNT * 100 / $TOTAL" | bc)
    echo "  音频文件: $AUDIO_COUNT / $TOTAL (${PROGRESS}%)"
    echo "  目录大小: $(du -sh audio_cache/ 2>/dev/null | cut -f1)"
else
    echo "  ⚠️  audio_cache 目录不存在"
fi

# 检查 RVC 服务器
if curl -s http://localhost:8765/health > /dev/null 2>&1; then
    echo "  RVC 服务器: ✅ 运行中"
else
    echo "  RVC 服务器: ❌ 未运行"
fi

# 检查生成进程
if ps aux | grep -E "generate_audio_cache.py" | grep -v grep > /dev/null 2>&1; then
    echo "  音频生成: 🔄 进行中"
else
    echo "  音频生成: ⏸️  未运行"
fi

cat << 'EOF'

📝 工作流程
-----------------------------------------------------------

  第一步：生成音频（一次性操作，需要 2-3 小时）
    $ ./generate_audio.sh

    说明：
    - 会自动启动 RVC 服务器
    - 批量生成所有单词的语音
    - 生成过程可随时中断，再次运行会继续
    - 音频保存在 audio_cache/ 目录

  第二步：压缩音频包（可选，用于分享或备份）
    $ ./compress_audio.sh

    说明：
    - 将 audio_cache/ 打包为 .tar.gz
    - 压缩后约 50-100 MB
    - 可以分享给其他人使用

  第三步：使用离线语音
    $ trunk serve --open

    说明：
    - 启动应用，自动加载离线语音
    - 点击 Live2D 即可听到单词发音
    - 无需运行 RVC 服务器

🔍 常用命令
-----------------------------------------------------------

  查看生成日志：
    $ tail -f audio_generation.log

  查看当前进度：
    $ ls audio_cache/*.wav | wc -l

  查看音频包大小：
    $ du -sh audio_cache/

  手动压缩音频：
    $ tar -czf audio_cache.tar.gz audio_cache/

  解压音频包：
    $ tar -xzf audio_cache.tar.gz

🚀 快速开始（从头开始）
-----------------------------------------------------------

  1. 安装依赖
     $ python3 -m venv venv
     $ source venv/bin/activate
     $ pip install -r requirements.txt

  2. 生成音频（需要 2-3 小时）
     $ ./generate_audio.sh
     （或者在后台运行：nohup ./generate_audio.sh &）

  3. 等待完成后，启动应用
     $ trunk serve --open

  4. 点击 Live2D 听单词发音！

📦 使用已有音频包
-----------------------------------------------------------

  如果你已经有了音频包：

  1. 解压
     $ tar -xzf cet6-audio-cache-*.tar.gz

  2. 启动应用
     $ trunk serve --open

  3. 享受离线学习！

🛠️ 故障排除
-----------------------------------------------------------

  音频生成失败：
    - 检查 RVC 服务器是否运行
    - 查看日志：tail -f audio_generation.log
    - 重新运行：./generate_audio.sh

  音频无法播放：
    - 检查 audio_cache/ 目录是否存在
    - 检查 cache_index.json 是否存在
    - 重新构建：trunk build --release

  RVC 服务器启动失败：
    - 检查 Python 环境：source venv/bin/activate
    - 检查依赖：pip install -r requirements.txt
    - 查看日志：cat rvc_server.log

📖 更多信息
-----------------------------------------------------------

  详细文档：README.md
  项目地址：https://github.com/lite-tx/cet6-flashcards

  快捷操作：
    ← →  切换生词
    ↑ ↓  切换复习单词
    点击卡片  翻转查看释义
    点击 Live2D  朗读当前单词

💡 提示
-----------------------------------------------------------

  - 首次生成需要较长时间，但之后可以永久使用
  - 音频包可以分享给其他人，无需重复生成
  - 压缩后的音频包约 50-100 MB，方便传输
  - 使用离线语音播放速度更快，无需等待

EOF
