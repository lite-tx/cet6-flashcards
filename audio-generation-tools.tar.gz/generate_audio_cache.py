#!/usr/bin/env python3
"""
预生成所有单词的 RVC 语音文件
"""

import json
import requests
import os
import asyncio
import aiohttp
import aiofiles
from pathlib import Path
from typing import List, Dict
import time
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# RVC 服务器配置
RVC_SERVER_URL = "http://localhost:8765"
AUDIO_CACHE_DIR = "audio_cache"

# 语音参数
TTS_PARAMS = {
    "rate": "+0%",
    "pitch": "+0Hz"
}

class AudioCacheGenerator:
    def __init__(self, words_file: str, output_dir: str = AUDIO_CACHE_DIR):
        self.words_file = words_file
        self.output_dir = Path(output_dir)
        self.words: List[str] = []
        self.session = None

        # 确保输出目录存在
        self.output_dir.mkdir(exist_ok=True)

    def load_words(self) -> None:
        """加载单词列表"""
        try:
            with open(self.words_file, 'r', encoding='utf-8') as f:
                words_data = json.load(f)

            # 提取所有单词
            self.words = [item['word'] for item in words_data]
            logger.info(f"加载了 {len(self.words)} 个单词")

        except Exception as e:
            logger.error(f"加载单词文件失败: {e}")
            raise

    async def check_rvc_server(self) -> bool:
        """检查 RVC 服务器是否可用"""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                async with session.get(f"{RVC_SERVER_URL}/health") as response:
                    if response.status == 200:
                        logger.info("RVC 服务器连接正常")
                        return True
        except:
            logger.warning("无法连接到 RVC 服务器，将使用基础 TTS")
            return False

    async def generate_audio_for_word(self, word: str, session: aiohttp.ClientSession) -> bool:
        """为单个单词生成音频文件"""
        output_file = self.output_dir / f"{word.lower()}.wav"

        # 如果文件已存在，跳过
        if output_file.exists():
            logger.debug(f"音频文件已存在: {output_file}")
            return True

        try:
            # 准备请求数据
            payload = {
                "text": word,
                **TTS_PARAMS
            }

            # 发送请求到 RVC 服务器
            async with session.post(
                f"{RVC_SERVER_URL}/tts",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                if response.status == 200:
                    # 保存音频文件
                    content_type = response.headers.get('content-type', '')

                    if 'audio' in content_type:
                        async with aiofiles.open(output_file, 'wb') as f:
                            async for chunk in response.content.iter_chunked(8192):
                                await f.write(chunk)

                        logger.info(f"生成音频: {word} -> {output_file}")
                        return True
                    else:
                        logger.error(f"响应不是音频格式: {word}, content-type: {content_type}")
                        return False
                else:
                    error_text = await response.text()
                    logger.error(f"生成音频失败: {word}, status: {response.status}, error: {error_text}")
                    return False

        except asyncio.TimeoutError:
            logger.error(f"生成音频超时: {word}")
            return False
        except Exception as e:
            logger.error(f"生成音频异常: {word}, error: {str(e)}")
            return False

    async def generate_all_audios(self, batch_size: int = 10) -> None:
        """批量生成所有单词的音频"""
        if not self.words:
            logger.error("单词列表为空")
            return

        logger.info(f"开始生成 {len(self.words)} 个单词的音频文件...")

        # 检查 RVC 服务器
        rvc_available = await self.check_rvc_server()

        # 创建连接器
        connector = aiohttp.TCPConnector(limit=batch_size)
        timeout = aiohttp.ClientTimeout(total=30)

        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            success_count = 0
            failed_count = 0
            skipped_count = 0

            # 分批处理
            for i in range(0, len(self.words), batch_size):
                batch = self.words[i:i + batch_size]
                logger.info(f"处理批次 {i//batch_size + 1}/{(len(self.words) + batch_size - 1)//batch_size}: {batch}")

                # 并发处理当前批次
                tasks = [self.generate_audio_for_word(word, session) for word in batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                # 统计结果
                for j, result in enumerate(results):
                    word = batch[j]
                    if isinstance(result, Exception):
                        logger.error(f"处理 {word} 时出现异常: {result}")
                        failed_count += 1
                    elif result is True:
                        # 检查是否是跳过的情况（文件已存在）
                        if (self.output_dir / f"{word.lower()}.wav").exists() and \
                           j < len([w for w in batch if (self.output_dir / f"{w.lower()}.wav").exists()]):
                            skipped_count += 1
                        else:
                            success_count += 1
                    else:
                        failed_count += 1

                # 批次间短暂休息，避免过载
                if i + batch_size < len(self.words):
                    await asyncio.sleep(1)

            logger.info(f"音频生成完成! 成功: {success_count}, 失败: {failed_count}, 跳过: {skipped_count}")

    def generate_cache_index(self) -> None:
        """生成缓存索引文件"""
        index_file = self.output_dir / "cache_index.json"

        # 获取所有音频文件
        audio_files = {}
        for audio_file in self.output_dir.glob("*.wav"):
            word_name = audio_file.stem
            audio_files[word_name] = {
                "file": str(audio_file),
                "size": audio_file.stat().st_size,
                "created": audio_file.stat().st_ctime
            }

        # 保存索引
        cache_info = {
            "total_count": len(audio_files),
            "generated_time": time.time(),
            "rvc_enabled": True,
            "words": audio_files
        }

        with open(index_file, 'w', encoding='utf-8') as f:
            json.dump(cache_info, f, indent=2, ensure_ascii=False)

        logger.info(f"缓存索引已生成: {index_file}, 包含 {len(audio_files)} 个单词")

    async def run(self) -> None:
        """运行生成任务"""
        try:
            # 加载单词
            self.load_words()

            # 生成音频
            await self.generate_all_audios()

            # 生成索引
            self.generate_cache_index()

            logger.info("所有任务完成!")

        except Exception as e:
            logger.error(f"运行失败: {e}")
            raise

async def main():
    """主函数"""
    words_file = "4-CET6-顺序.json"

    generator = AudioCacheGenerator(words_file)
    await generator.run()

if __name__ == "__main__":
    asyncio.run(main())